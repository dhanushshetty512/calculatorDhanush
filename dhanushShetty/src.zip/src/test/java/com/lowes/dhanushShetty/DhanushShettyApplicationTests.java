package com.lowes.dhanushShetty;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DhanushShettyApplicationTests {

	@Test
	void contextLoads() {
	}

}
