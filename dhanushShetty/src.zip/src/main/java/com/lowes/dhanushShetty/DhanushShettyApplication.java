package com.lowes.dhanushShetty;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DhanushShettyApplication {

	public static void main(String[] args) {
		SpringApplication.run(DhanushShettyApplication.class, args);
	}

}
