package com.lowes.dhanushShetty.Repository;

import com.lowes.dhanushShetty.Model.CalculatorModel;
import org.springframework.data.repository.CrudRepository;


public interface CalculatorRepo extends CrudRepository<CalculatorModel, Integer> {}
